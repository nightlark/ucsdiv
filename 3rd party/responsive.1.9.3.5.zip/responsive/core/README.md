responsivecore
==============

Core files and functions for the responsive theme
