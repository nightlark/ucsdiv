CyberChimps Pro Responsive Starter Theme
========================================

Visit http://CyberChimps.com for more information and instructions.

Theme Homepage -  http://cyberchimps.com/cyberchimpspro/

Licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

Bootstrap is licensed under APLv2 - https://github.com/twitter/bootstrap/blob/master/LICENSE

HTML5shiv is bundled with this theme and adds HTML5 elements to browsers that are not HTML5 enabled Dual Licensed under MIT/GPL2 - http://opensource.org/licenses/mit-license.php / GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

jCarousel is dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php) and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.

Slimbox is licensed under the MIT license - http://www.opensource.org/licenses/mit-license.php

jQuery UI Touch Punch is dual licensed under the MIT or GPL Version 2 licenses.

CSS3PIE is bundled with this theme and adds some CSS3 styles to ie versions licensed under GNU General Public License v2.0 - http://www.gnu.org/licenses/gpl-2.0.html

-------------------------------------------------------------------------------------------------

For updated documentation, walkthroughs, and support please visit http://cyberchimps.com/

For updated docs please visit http://cyberchimps.com/help/

For the support forum please visit: http://cyberchimps.com/forum/pro/

For more support options please visit http://cyberchimps.com/